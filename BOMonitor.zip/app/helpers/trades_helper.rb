module TradesHelper
end
