class Dashboard < ActiveRecord::Base
	
end
