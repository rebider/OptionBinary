require 'test_helper'

class StrategyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
