require 'test_helper'

class BrokerAccountTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
