require 'test_helper'

class AccountBalanceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
